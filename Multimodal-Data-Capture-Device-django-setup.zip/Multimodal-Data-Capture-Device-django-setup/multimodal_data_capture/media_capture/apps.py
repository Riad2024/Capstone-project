from django.apps import AppConfig


class MediaCaptureConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'media_capture'
